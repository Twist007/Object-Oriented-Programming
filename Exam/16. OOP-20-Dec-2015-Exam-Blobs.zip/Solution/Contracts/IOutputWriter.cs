﻿namespace Blobs.Contracts
{
    public interface IOutputWriter
    {
        void WriteLine(string line);
    }
}
