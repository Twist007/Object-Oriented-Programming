﻿namespace Blobs.Contracts
{
    public interface IInputReader
    {
        string ReadLine();
    }
}
