﻿namespace Blobs.Models.Attacks
{
    using Contracts;

    public class PutridFart : Attack
    {
        public PutridFart(IBlob blob)
            : base(blob)
        {
        }
    }
}