﻿namespace Blobs.Models
{
    public class Inflated : Behavior
    {

    }
}
