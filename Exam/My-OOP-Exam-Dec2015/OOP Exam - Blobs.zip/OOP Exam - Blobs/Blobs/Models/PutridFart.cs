﻿namespace Blobs.Models
{
    public class PutridFart : Attack
    {

    }
}
