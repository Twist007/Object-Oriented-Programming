﻿using Blobs.Interfaces;

namespace Blobs.Models
{
    public abstract class Behavior : IBehavior
    {

    }
}
