﻿namespace Blobs.Models
{
    class Aggressive : Behavior
    {
    }
}
