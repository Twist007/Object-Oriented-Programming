﻿using Blobs.Interfaces;

namespace Blobs.Models
{
    public class Blobplode:Attack
    {
    }
}
