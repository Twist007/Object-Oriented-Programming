﻿using Blobs.Core;
using Blobs.Models;

namespace Blobs
{
    class Program
    {
        static void Main(string[] args)
        {
           var engine = new Engine();
            engine.Run();
        }
    }
}
