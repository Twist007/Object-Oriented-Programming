﻿namespace Blobs.Interfaces
{
    public interface IOutputWriter
    {
        void PrintLine(string line);
    }
}
