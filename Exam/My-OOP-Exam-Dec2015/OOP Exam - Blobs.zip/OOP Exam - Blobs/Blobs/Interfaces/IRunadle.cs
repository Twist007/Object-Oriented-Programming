﻿namespace Blobs.Interfaces
{
    public interface IRunadle
    {
        void Run();
    }
}
