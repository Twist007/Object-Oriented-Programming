﻿namespace Blobs.Interfaces
{
    public interface IBehavior
    {
        //bool IsTriggered { get; }
    }
}
