﻿using System;
using Blobs.Interfaces;

namespace Blobs.IO
{
    public class IConsoleHandler : IConsoleIOHandler
    {
        public string ReadLine()
        {
            return Console.ReadLine();
        }

        public void Write(string message,params object[] paramObjects)
        {
            Console.Write(message, paramObjects);
        }
        public void WriteLine(string message,params object[] paramObjects)
        {
            Console.WriteLine(message, paramObjects);
        }
    }
}