﻿namespace Blobs.Interfaces
{
    public interface IConsoleInputHandler
    {
        string ReadLine();
    }
}