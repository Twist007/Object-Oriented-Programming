﻿namespace Blobs.Interfaces
{
    public interface IConsoleIOHandler : IConsoleInputHandler, IConsoleOutputHandler
    {
         
    }
}