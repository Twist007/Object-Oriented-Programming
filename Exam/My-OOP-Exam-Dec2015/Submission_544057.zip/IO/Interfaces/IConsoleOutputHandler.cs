﻿namespace Blobs.Interfaces
{
    public interface IConsoleOutputHandler
    {
        void Write(string message,params object[] paramObjects);
        void WriteLine(string message,params object[] paramObjects);
    }
}