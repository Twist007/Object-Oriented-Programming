﻿using Blobs.Interfaces;

namespace Blobs.Models.Behaviors
{
    public class InflatedBehavior : IBehavior
    {
        private const int HealthGained = 50;
        private int ConsecutiveHealthLost = 10;
        private bool hasPassedOneTurn = false;

        public IBlob Blob { get; set; }
        public void ApplyBehavior()
        {
            this.Blob.Health += HealthGained;
        }

        public void RemoveBehaviorEffect()
        {
        }

        public void ExecuteBehaviorTurnAction()
        {
            if (this.hasPassedOneTurn == true)
            {
                this.Blob.Health -= this.ConsecutiveHealthLost;
                if (this.Blob.Health < 0)
                {
                    this.Blob.Health = 0;
                }
            }
            else
            {
                this.hasPassedOneTurn = true;
            }
        }
    }
}