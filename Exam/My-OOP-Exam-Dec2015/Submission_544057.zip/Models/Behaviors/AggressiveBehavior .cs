﻿using Blobs.Interfaces;

namespace Blobs.Models.Behaviors
{
    public class AggressiveBehavior : IBehavior
    {
        private const int ConsecutiveDmgLost = 5;
        private int damageAtTimeOfActivation;
        private IBlob blob;
        private bool hasOneTurnPassed = false;

      
        
        public void ApplyBehavior()
        {
            this.damageAtTimeOfActivation = this.Blob.Damage;
            this.Blob.Attack.Damage *= 2;
            this.blob.Damage *= 2;
        }

        public void RemoveBehaviorEffect()
        {
        }

        public IBlob Blob
        {
            get
            {
                return this.blob;
            }

            set
            {
                this.blob = value;
            }
        }
        public void ExecuteBehaviorTurnAction()
        {
            if (this.hasOneTurnPassed == true)
            {

                if (this.Blob.Damage - ConsecutiveDmgLost >= this.damageAtTimeOfActivation)
                {
                    this.Blob.Damage -= ConsecutiveDmgLost;
                }
            }
            else
            {
                this.hasOneTurnPassed = true;
            }
        }
    }
}