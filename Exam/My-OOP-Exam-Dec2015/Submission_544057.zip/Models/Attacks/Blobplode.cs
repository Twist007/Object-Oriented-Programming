﻿using System;
using Blobs.Interfaces;

namespace Blobs.Models.Attacks
{
    public class Blobplode : IAttack
    {
        private IBlob blob;
        private int damage;
        public Blobplode()
        {
        }

        public IBlob Blob
        {
            get { return this.blob; }
            set
            {
                this.blob = value;
                this.damage = this.blob.Damage;
            }
        }

        public int Damage
        {
            get { return this.damage *= 2; }
            set { this.damage = value; }
        }

        public void ApplySideEffect()
        {
            this.Blob.Health -= (int)Math.Floor(this.Blob.Health/2.00);
            if (this.Blob.Health < 1)
            {
                this.Blob.Health = 1;
            }
        }

        public void ResetAttack()
        {
            this.damage = this.blob.Damage;
        }
    }
}