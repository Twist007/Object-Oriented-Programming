﻿using System;
using Blobs.Interfaces;

namespace Blobs.Models.Attacks
{
    public class PutridFart : IAttack
    {
        private int damage;
        private IBlob blob;
        public PutridFart()
        {
        }

        

        public int Damage
        {
            get { return this.Blob.Damage; }
            set { this.damage = value; }
        }
        public IBlob Blob
        {
            get { return this.blob; }
            set
            {
                this.blob = value;
                this.damage = this.blob.Damage;
            }
        }

        public void ResetAttack()
        {
            this.damage = this.blob.Damage;
        }
        public void ApplySideEffect()
        {
            
        }
    }
}