﻿using System;
using System.Text;
using System.Threading;
using Blobs.Core.Commands;
using Blobs.Interfaces;
using Blobs.Models.Behaviors;

namespace Blobs.Models
{
    public class Blob : IBlob
    {
        public static bool VerboseReport = false;
        private int lastHealth;
        public Blob(string name, int health, int damage, IBehavior behavior, IAttack attack)
        {
            this.Name = name;
            this.Health = health;
            this.Damage = damage;
            this.Behavior = behavior;
            this.Attack = attack;
        }
        public string Name { get; set; }
        public int Health { get; set; }
        
        public int Damage { get; set; }

        public IAttack Attack { get; set; }
        public IBehavior Behavior { get;  set; }
        public IAttack ProduceAttack()
        {
            this.lastHealth = this.Health;
            this.Attack.ApplySideEffect();
            if (this.ShouldActivateBihavior)
            {
                this.HasBehaiviorBeenActivated = true;
                this.Behavior.ApplyBehavior();
            }
            this.Attack.Damage = this.Damage;
            return this.Attack;
        }


        public void ReceiveAttack(IAttack attack)
        {
            this.lastHealth = this.Health;
            this.Health -= attack.Damage;
            if (this.Health < 0)
            {
                this.Health = 0;
                if (VerboseReport)
                {
                    Console.WriteLine($"Blob {this.Name} was killed");
                }
            }
            if (this.ShouldActivateBihavior)
            {
                this.HasBehaiviorBeenActivated = true;
                this.Behavior.ApplyBehavior();
            }
        }
        //TODO: If behavior is triggered second time raise an Error
        public void Update()
        {
            if (this.isAlive)
            {
                if (this.HasBehaiviorBeenActivated)
                {
                    this.Attack.Damage = this.Damage;
                    this.Behavior.ExecuteBehaviorTurnAction();
                }
                else
                {
                    if (this.ShouldActivateBihavior)
                    {
                        this.HasBehaiviorBeenActivated = true;
                        this.Behavior.ApplyBehavior();
                    }
                }
            }
            
        }

   
        public bool HasBehaiviorBeenActivated { get; set; }

        public bool isAlive
        {
            get
            {
                if (this.Health == 0)
                {
                    return false;
                }
                else
                {
                    return true;
                }
            }
        }
        

        private bool ShouldActivateBihavior
        {
            get
            {
                if (this.Health <= (this.lastHealth/2) && this.HasBehaiviorBeenActivated == false)
                {
                    
                    if (VerboseReport)
                    {
                        Console.WriteLine($"Blob {this.Name} toggled {this.Behavior.GetType().Name}");
                    }
                    return true;
                }
                else
                {

                    return false;
                }
            }
        }

        public override string ToString()
        {
            StringBuilder output = new StringBuilder();
         
            if (this.isAlive)
            {
                output.Append(string.Format("Blob {0}: {1} HP, {2} Damage", this.Name, this.Health, this.Damage));
            }
            else
            {
                output.Append(string.Format("Blob {0} KILLED", this.Name));
            }
            return output.ToString();
        }
    }
}