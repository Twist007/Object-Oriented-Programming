﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Blobs.Core;
using Blobs.Interfaces;
using Blobs.IO;

namespace Blobs
{
    class BlobsMain
    {
        static void Main(string[] args)
        {
            IDatabase database = new Database();
            ICommandExecutor commandExecutor = new CommandExecutor();
            IConsoleIOHandler consoleHandler = new IConsoleHandler();
            IEngine engine = new Engine(database, commandExecutor, consoleHandler);

            engine.Run();
        }
    }
}
