﻿using Blobs.Interfaces;

namespace Blobs.Core.Commands
{
    public abstract class CommandBase : ICommand
    {
        protected CommandBase(IDatabase db)
        {
            this.Database = db;
        }

        public IDatabase Database { get; protected set; }
        public abstract void Execute();
    }
}