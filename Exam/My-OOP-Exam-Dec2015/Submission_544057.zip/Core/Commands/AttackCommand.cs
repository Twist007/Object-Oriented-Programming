﻿using Blobs.Interfaces;

namespace Blobs.Core.Commands
{
    public class AttackCommand : CommandBase
    {
        private IBlob attacker;
        private IBlob target;

        public AttackCommand(IBlob attacker, IBlob target, IDatabase db) : base(db)
        {
            this.attacker = attacker;
            this.target = target;
        }

        public override void Execute()
        {
            IAttack attack = this.attacker.ProduceAttack();
            this.target.ReceiveAttack(attack);
        }
    }
}