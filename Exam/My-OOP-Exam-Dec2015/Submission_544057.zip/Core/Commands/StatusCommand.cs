﻿using System;
using Blobs.Interfaces;

namespace Blobs.Core.Commands
{
    public class StatusCommand : CommandBase
    {
        public StatusCommand(IDatabase db, IConsoleIOHandler consoleHandler) : base(db)
        {
        }

        public override void Execute()
        {
            foreach (IBlob blob in this.Database.Blobs)
            {//TODO: IO
                Console.WriteLine(blob);
            }
        }
    }
}