﻿using System;
using System.Windows.Input;
using Blobs.Interfaces;
using Blobs.Models;
using Blobs.Models.Attacks;
using Blobs.Models.Behaviors;
using ICommand = Blobs.Interfaces.ICommand;

namespace Blobs.Core.Commands
{
    public class CreateCommand : CommandBase
    {
        private string name;
        private int health;
        private int damage;
        private IBehavior behavior;
        private IAttack attack;

        public CreateCommand( string name, int health, int damage, string behaviorName, string attackName, IDatabase db) : base(db)
        {
            this.name = name;
            this.health = health;
            this.damage = damage;
            switch (behaviorName)
            {
                case "Inflated":
                    this.behavior = new InflatedBehavior();
                    break;
                case "Aggressive":
                    this.behavior = new AggressiveBehavior();
                    break;
                default:
                    throw new NotImplementedException("Not implemented Behavior type... or invalid begavior name");
            }
            switch (attackName)
            {
                case "PutridFart":
                    this.attack = new PutridFart();
                    break;
                case "Blobplode":
                    this.attack = new Blobplode();
                    break;
                default:
                    throw new NotImplementedException("Not implemented Attack type... or invalid attack name");
            }
        }

        public override void Execute()
        {
            IBlob blob = new Blob(this.name, this.health, this.damage, this.behavior, this.attack);
            this.Database.Blobs.Add(blob);
            blob.Behavior = this.behavior;
            blob.Attack = this.attack;
            this.attack.Blob = blob;
            this.behavior.Blob = blob;
        }
    }
}