﻿using System;

namespace Blobs.Core.Exceptions
{
    public class BlobsNullException : ArgumentNullException
    {
        public BlobsNullException(string paramName, string message) : base(paramName, message)
        {
        }
    }
}