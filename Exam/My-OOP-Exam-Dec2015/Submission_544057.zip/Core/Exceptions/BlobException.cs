﻿using System;

namespace Blobs.Core.Exceptions
{
    public class BlobException : ApplicationException
    {
        public BlobException(string message) : base(message)
        {
            
        }
    }
}