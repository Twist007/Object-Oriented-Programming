﻿using System.Collections.Generic;
using Blobs.Interfaces;

namespace Blobs.Core
{
    public class Database : IDatabase
    {
        public ICollection<IBlob> Blobs { get; } = new List<IBlob>();
    }
}