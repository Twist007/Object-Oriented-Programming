﻿using System;
using System.Linq;
using Blobs.Core.Exceptions;
using Blobs.Interfaces;

namespace Blobs.Core
{
    public class Engine : IEngine
    {
        private IDatabase db;
        private ICommandExecutor commandExecutor;
        private IConsoleIOHandler consoleHandler;

        public Engine(IDatabase db, ICommandExecutor commandExecutor, IConsoleIOHandler consoleHander)
        {
            this.Db = db;
            this.CommandExecutor = commandExecutor;
            this.ConsoleHandler = consoleHander;
        }

        public IDatabase Db
        {
            get
            {
                return this.db;
            }
            private set
            {
                if (value == null)
                {
                    throw new BlobsNullException("Database", "Database cannot be null");
                }
                this.db = value;
            }
        }

        public ICommandExecutor CommandExecutor
        {
            get
            {
                return this.commandExecutor;
            }
            private set
            {
                if (value == null)
                {
                    throw new BlobsNullException("CommandExecutor", "CommandExecutor cannot be null");
                }
                this.commandExecutor = value;
            }
        }

        public IConsoleIOHandler ConsoleHandler
        {
            get
            {
                return this.consoleHandler;
            }
            private set
            {
                if (value == null)
                {
                    throw new BlobsNullException("ConsoleHandler", "ConsoleHandler cannot be null");
                }
                this.consoleHandler = value;
            }
        }
        
       
        public void Run()
        {
            string inputString = this.ConsoleHandler.ReadLine();
            while (inputString != "drop")
            {
                string[] inputParams = inputString.Split(new char[] {' '}, StringSplitOptions.RemoveEmptyEntries);
                string commandName = inputParams[0];
                try
                {
                    foreach (var blob in this.db.Blobs)
                    {
                        blob.Update();
                    }
                    this.CommandExecutor.ExecuteCommand(commandName, inputParams.Skip(1).ToArray(), this.Db, this.ConsoleHandler);
                    
                } //TODO: Implement custom Exceptions
                catch (Exception e)
                {
                    this.ConsoleHandler.WriteLine(e.Message);
                }
                finally
                {
                    inputString = this.ConsoleHandler.ReadLine();
                }
            }
        }
    }
}