﻿using System.Security.Cryptography.X509Certificates;

namespace Blobs.Interfaces
{
    public interface ICommand
    {
        IDatabase Database { get; }
        void Execute();
    }
}