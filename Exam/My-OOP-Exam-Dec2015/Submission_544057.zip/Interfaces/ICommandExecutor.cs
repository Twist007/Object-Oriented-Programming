﻿namespace Blobs.Interfaces
{
    public interface ICommandExecutor
    {
        void ExecuteCommand(string commandName, string[] inputParams, IDatabase db, IConsoleIOHandler consoleHandler);
    }
}