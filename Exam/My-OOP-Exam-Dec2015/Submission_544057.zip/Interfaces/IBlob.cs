﻿using System.ComponentModel.Design;

namespace Blobs.Interfaces
{
    public interface IBlob
    {
        string Name { get; set; } 
        int Health { get; set; } 
        int Damage { get; set; } 
        IBehavior Behavior { get; set; }
        IAttack ProduceAttack();
        IAttack Attack { get; set; }
        void ReceiveAttack(IAttack attack);
        void Update();
        bool HasBehaiviorBeenActivated { get; }
        bool isAlive { get; }
    }
}