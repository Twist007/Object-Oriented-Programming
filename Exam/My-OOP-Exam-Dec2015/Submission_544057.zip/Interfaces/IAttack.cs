﻿namespace Blobs.Interfaces
{
    public interface IAttack
    {
        IBlob Blob { get; set; }
        int Damage { get; set; }

        void ApplySideEffect();
        void ResetAttack();
    }
}