﻿using System.Security.Cryptography.X509Certificates;

namespace Blobs.Interfaces
{
    public interface IBehavior
    {
        void ApplyBehavior();
        void RemoveBehaviorEffect();
        void ExecuteBehaviorTurnAction();
        IBlob Blob { get; set; }
    }
}